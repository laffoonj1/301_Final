SELECT *
FROM final_customers
WHERE customerid = :customerid