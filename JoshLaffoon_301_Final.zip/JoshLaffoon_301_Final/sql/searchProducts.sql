SELECT *
FROM final_products
WHERE productname like :searchTerm;