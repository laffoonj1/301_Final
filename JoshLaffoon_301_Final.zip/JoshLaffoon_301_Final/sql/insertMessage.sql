INSERT INTO final_orders (message, name, productname, address)
VALUES(:message, :name, :productname, :address)