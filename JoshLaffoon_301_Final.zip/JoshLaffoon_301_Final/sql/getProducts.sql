SELECT *
FROM final_products
