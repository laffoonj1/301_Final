INSERT INTO final_members (name, address)
VALUES(:name, :address)